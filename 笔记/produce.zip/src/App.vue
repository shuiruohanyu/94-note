<template>
  <div id="app">
    <!-- 放入我们的produce-list组件  -->
    <produce-list></produce-list>
  </div>
</template>
<script>
import ProduceList from "./produce-list.vue"; // 引入了一个组件对象 给对象起了一个别名
// 组件注册 的两种方式  全局注册  局部注册
// 局部注册 => 应该在当前组件实例上注册
export default {
  name: "App",
  data() {
    return {};
  },
  components: {
    // 组件名:组件对象
    "produce-list": ProduceList
  }
};
</script>

<style>
</style>
