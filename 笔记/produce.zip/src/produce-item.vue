<template>
  <!-- 这个组件做为每个商品项存在 -->
  <div class="produce-item">
    <!-- 图片 -->
    <img
      src="http://img.alicdn.com/bao/uploaded/i1/2047509713/O1CN01PBWvbu2LcbZYzXhQZ_!!2047509713-0-pixelsss.jpg"
      alt
    />
    <!-- 价格 -->
    <span>¥358.00</span>
    <!-- 商品名称 -->
    <span>花花公子春季百搭牛仔夹克</span>
    <!-- 店铺名称 -->
    <span>优衣库官方旗舰店</span>
  </div>
</template>

<script>
export default {};
</script>

<style>
.produce-item {
  display: flex;
  flex-direction: column;
  border: 1px solid #ccc;
  margin: 20px;
  width: 200px;
}
.produce-item img {
  width: 200px;
  height: 200px;
}
.produce-item span {
  display: inline-block;
}
.produce-item span:nth-child(2) {
  color: red;
  font-size: 20px;
  height: 40px;
  line-height: 40px;
  font-weight: bold;
  padding: 0 10px;
}
.produce-item span:nth-child(3) {
  font-size: 16px;
  height: 30px;
  line-height: 30px;
  padding: 0 10px;
}
.produce-item span:nth-child(4) {
  font-size: 16px;
  height: 30px;
  line-height: 30px;
  padding: 0 10px;
  color: #999;
  text-decoration: underline;
  cursor: pointer;
}
</style>