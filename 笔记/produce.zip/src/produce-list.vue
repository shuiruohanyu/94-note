<template>
  <div class="produce-list">
    <produce-item v-for="item in 10" :key="item"></produce-item>
  </div>
</template>

<script>
import ProduceItem from "./produce-item"; // 必须注册哦
export default {
  components: {
    "produce-item": ProduceItem // 注册完毕就可以使用了
  }
};
</script>

<style>
.produce-list {
  margin: 0 auto;
  display: flex;
  width: 1300px;
  overflow: hidden;
  flex-wrap: wrap;
  justify-content: center;
}
</style>